ui <- fluidPage(
  DTOutput("table1")
)

server <- function(input, output) {
  
  output$table1 <- renderDT({
    dataset1 <- read.csv("All Clubs Data.csv")
    datatable(dataset1)
  })
  
}


shinyApp(ui, server)
