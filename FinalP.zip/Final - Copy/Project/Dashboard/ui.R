######################  UI PART FOR WEBPAGE   ##########################

ui <- dashboardPage(
  #############  DASHBOARD HEADER
  dashboardHeader(
    title = tags$h1("90 MINS STAT", style = "font-family: NEON LED Light; font-size: 29px; color: lime; padding: 2px 0; line-height: 0.25;"),
    titleWidth = 230,
    tags$li(
      a(
        href = "https://github.com/Mubashir42884",
        target = "_blank",
        style = "font-family: LEMON MILK;" ,
        icon("github"),
        "My GitHub"
      ),
      class = "dropdown"
    ),
    tags$li(
      a(
        href = "https://www.espnfc.com/",
        target = "_blank",
        style = "font-family: LEMON MILK;" ,
        icon("futbol"),
        "ESPN FC",
        target = "_blank"
      ),
      class = "dropdown"
    ),
    tags$li(
      a(
        href = "https://www.foxsports.com/soccer",
        style = "font-family: LEMON MILK;" ,
        icon("tv"),
        "Fox Sports Soccer"
      ),
      class = "dropdown"
    )
  ), 
  
  #############  DASHBOARD SIDEBAR
  dashboardSidebar(
    tags$head(tags$style(
      HTML(
        "
        /* Make the sidebar fixed and cover the full height of the page */
        .sidebar {
          position: fixed;
          height: 100%;
          overflow-y: none;
        }

        /* Remove the top margin from the first sidebar menu item */
        .sidebar .treeview:first-child > a {
          margin-top: 0;
        }

        /* Remove the sidebar's bottom margin */
        .sidebar {
          margin-bottom: 0;
        }
      "
      )
    )),
    sidebarMenu(
      menuItem(" About", tabName = "about", icon = icon("info-circle")),
      menuItem(" Dataset", tabName = "dataset", icon = icon("database")),
      menuItem(" Leagues", tabName = "leagues", icon = icon("futbol")),
      menuItem(" Clubs", tabName = "clubs", icon = icon("people-group")),
      menuItem(" Players", tabName = "players", icon = icon("user")),
      menuItem(
        " Comparison",
        tabName = "comparison",
        icon = icon("code-compare")
      ),
      menuItem(" Visuals", tabName = "visuals", icon = icon("chart-line"))
    )
  ),
  
  #############  DASHBOARD BODY
  dashboardBody(
    tabItems(
      #################################### ABOUT
      tabItem(
        tabName = "about",
        h2("About", style = "font-family: LEMON MILK;"),
        p(
          "This is a dashboard for exploring European Football data. The dataset has been collected by webscrapping using 'Rvest'. However, the main purpose of this dashboard is to show some real-time statistics of the European Football leagues, clubs and players. The dashboard might help you to get a good insight of the world of Football.",
          style = "font-family: Quicksand; font-weight: bolder;"
        ), 
        h4(
          "Created by: MUBASHIR MOHSIN;", br(),
          "AIUB ID: 20-42884-1", br(),
          "Department: Computer Science",
          align = "center",
          style = "font-family: Quicksand; font-weight: bolder;"
        ),
        p(br(),br(),"Copyright ⓒ 2023", align = "center", style = "font-family: Quicksand; font-weight: bolder;")
      ),
      #################################### DATASET
      tabItem(
        tabName = "dataset",
        h2("Dataset", style = "font-family: LEMON MILK;"),
        p("This dashboard uses the following datasets:", style = "font-family: Quicksand; font-weight: bolder;"),
        sidebarMenu(
          menuItem(
            "Clubs Dataset",
            tabName = "clubs_dataset",
            icon = icon("shield")
          ),
          menuItem(
            "Players Dataset",
            tabName = "players_dataset",
            icon = icon("people-group")
          )
        )
      ),
      ############################ CLUBS DATASET
      tabItem(
        tags$a(
          href = "#",
          icon("chevron-left"),
          "Go back",
          style = "font-family: Quicksand; font-weight: bolder;",
          onclick = "history.back()"
        ),
        tabName = "clubs_dataset",
        h2("Clubs Dataset", style = "font-family: LEMON MILK;"),
        DTOutput("table1")
      ),
      ############################ PLAYERS DATASET
      tabItem(
        tags$a(
          href = "#",
          icon("chevron-left"),
          "Go back",
          style = "font-family: Quicksand; font-weight: bolder;",
          onclick = "history.back()"
        ),
        tabName = "players_dataset",
        h2("Players Dataset", style = "font-family: LEMON MILK;"),
        DTOutput("table2")
      ),
      
      
      ################################## LEAGUES
      
      tabItem(
        tabName = "leagues",
        h2("Leagues", style = "font-family: LEMON MILK;"),
        p("Explore data by league here.", style = "font-family: Quicksand; font-weight: bolder;"),
        
        # League Information sub-item
        tabsetPanel(
          tabPanel(
            "League Information",
            style = "font-family: Quicksand; font-weight: bolder; font-size: 20px",
            fluidRow(
              column(
                2,
                img(
                  src = "https://logowik.com/content/uploads/images/premier-league3330.jpg",
                  height = 70,
                  width = 80
                )
              ),
              column(
                4,
                tags$a(href = "https://en.wikipedia.org/wiki/Premier_League", "English Premier League", target =
                         "_blank")
              ),
              column(
                2,
                img(
                  src = "https://assets.laliga.com/assets/logos/laliga-v/laliga-v-1200x1200.jpg",
                  height = 80,
                  width = 80
                )
              ),
              column(
                4,
                tags$a(href = "https://en.wikipedia.org/wiki/La_Liga", "La Liga", target =
                         "_blank")
              )
            ),
            fluidRow(
              column(
                2,
                img(
                  src = "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e9/Serie_A_logo_2022.svg/1193px-Serie_A_logo_2022.svg.png",
                  height = 80,
                  width = 80
                )
              ),
              column(
                4,
                tags$a(href = "https://en.wikipedia.org/wiki/Serie_A", "Serie A", target =
                         "_blank")
              ),
              column(
                2,
                img(
                  src = "https://upload.wikimedia.org/wikipedia/en/thumb/d/df/Bundesliga_logo_%282017%29.svg/1200px-Bundesliga_logo_%282017%29.svg.png",
                  height = 80,
                  width = 80
                )
              ),
              column(
                4,
                tags$a(href = "https://en.wikipedia.org/wiki/Bundesliga", "Bundesliga", target =
                         "_blank")
              )
            ),
            fluidRow(
              column(
                2,
                img(
                  src = "https://i.pinimg.com/originals/cf/f8/6a/cff86adb4903caa1061e67b10334ff42.jpg",
                  height = 90,
                  width = 80
                )
              ),
              column(
                4,
                tags$a(href = "https://en.wikipedia.org/wiki/Primeira_Liga", "Primeira Liga", target =
                         "_blank")
              ),
              column(
                2,
                img(
                  src = "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0f/Eredivisie_nieuw_logo_2017-.svg/1200px-Eredivisie_nieuw_logo_2017-.svg.png",
                  height = 60,
                  width = 80
                )
              ),
              column(
                4,
                tags$a(href = "https://en.wikipedia.org/wiki/Eredivisie", "Eredivisie", target =
                         "_blank")
              )
            ),
            fluidRow(column(
              2,
              img(
                src = "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Ligue1.svg/1200px-Ligue1.svg.png",
                height = 100,
                width = 80
              )
            ),
            column(
              4,
              tags$a(href = "https://en.wikipedia.org/wiki/Ligue_1", "Ligue 1", target =
                       "_blank")
            ))
          )
        )
      ), 
      
      ####################################### CLUBS
      tabItem(
        tabName = "clubs",
        h2("Top Clubs of Europe", style = "font-family: LEMON MILK;"),
        p(
          "Here is listed all the top 5 clubs from each league of Europe.",
          style = "font-family: Quicksand; font-weight: bolder;"
        ),
        fluidRow(column(width = 12,
                        uiOutput("club_tabs")))
      ),
      ###################################### PLAYERS
      
      players_tab <- tabItem(
        tabName = "players",
        h2("Top Players of Europe", style = "font-family: LEMON MILK; font-weight: bold; text-align: center;"),
        p("Here are the top 5 players from each league in Europe.",
          style = "font-family: Quicksand; font-weight: bolder;"),
        fluidRow(column(
          width = 12,
          uiOutput("player_tabs"),
          tags$style(
            HTML(
              ".tab-pane h3 {font-family: LEMON MILK; font-weight: bold; text-align: center;}"
            )
          )
        ))
      ),
      
      ####################################### COMPARISONS
      tabItem(
        tabName = "comparisons",
        h2("About", style = "font-family: LEMON MILK;"),
        p(
          "This is a dashboard for exploring European Football data. The dataset has been collected by webscrapping using 'Rvest'.\nHowever, the main purpose of this dashboard to show some real-time statistics of the European Football leagues, clubs and players.\nThe dashboard might help you to get a good insight of the world of Football.",
          style = "font-family: Quicksand;"
        ),
        p(
          "\n \n \nMUBASHIR MOHSIN; ID: 20-42884-1" ,
          align = "center",
          style = "font-family: Quicksand; font-weight: bolder;"
        ),
        p("\n \n \nCopyright ⓒ 2023" , align = "center", style = "font-family: Quicksand; font-weight: bolder;")
      ),
      
      ####################################### VISUALS
      tabItem(
        tabName = "visuals",
        h2("About", style = "font-family: LEMON MILK;"),
        p(
          "This is a dashboard for exploring European Football data. The dataset has been collected by webscrapping using 'Rvest'.\nHowever, the main purpose of this dashboard to show some real-time statistics of the European Football leagues, clubs and players.\nThe dashboard might help you to get a good insight of the world of Football.",
          style = "font-family: Quicksand;"
        ),
        p(
          "\n \n \nMUBASHIR MOHSIN; ID: 20-42884-1" ,
          align = "center",
          style = "font-family: Quicksand; font-weight: bolder;"
        ),
        p("\n \n \nCopyright ⓒ 2023" , align = "center", style = "font-family: Quicksand; font-weight: bolder;")
      )
    )
  )
)

###############################################################################



############################# FUNCTIONS FOR OUTPUT #############################

################################### FOR CLUBS OUTPUT

# Load the club data
club_data <- read.csv("Clubs.csv")

# Create a data frame with only the necessary columns
top_clubs <- club_data %>%
  filter(Position >= 1 & Position <= 5) %>%
  select(Club, LeagueNameLong, Points)

# Create a list of data frames, one for each league
league_clubs <- split(top_clubs, f = top_clubs$LeagueNameLong)

# Define the order of the leagues
league_order <-
  c(
    "English Premier League",
    "Spanish La Liga",
    "Italian Serie-A",
    "German Bundesliga",
    "French Ligue 1",
    "Dutch Eredivisie",
    "Portuguese Primeira Liga"
  )



###############################################################################




################################# SERVER #######################################

server <- function(input, output, session) {
  ################################ FOR LEAGUES OUTPUT #########################
  # Load data
  output$table1 <- renderDT({
    dataset1 <- read.csv("All Clubs Data.csv")
    datatable(dataset1)
  })
  
  output$table2 <- renderDT({
    dataset2 <- read.csv("All Squad Data.csv")
    datatable(dataset2)
  })
  
  ################################### FOR CLUBS OUTPUT #########################
  # Club Information sub-item
  output$club_tabs <- renderUI({
    lapply(league_order, function(league_name) {
      tabPanel("",
               style = "padding: 0;",
               fluidRow(column(
                 width = 12,
                 h4(league_name, style = "text-align: center; font-weight: bolder;")
               )),
               fluidRow(column(width = 12,
                               dataTableOutput(
                                 paste0("table_", league_name)
                               ))))
    })
  })
  
  # Output the club tables
  lapply(league_order, function(league_name) {
    output[[paste0("table_", league_name)]] <- renderDataTable({
      datatable(
        league_clubs[[league_name]][c("Club", "Points")],
        rownames = FALSE,
        options = list(
          dom = 't',
          paging = FALSE,
          ordering = TRUE,
          order = list(1, 'desc'),
          searching = FALSE,
          info = FALSE
        )
      )
    },
    options = list(dom = 't'))
  })
  
  
  ############################# FOR PLAYERS OUTPUT #############################
  
  # Read Top Players.csv into a dataframe
  top_players_df <- read.csv("Top Players.csv")
  
  # Create a list of league names
  leagues <- unique(top_players_df$LeagueNameLong)
  
  # Create a function to generate tableOutput for each league
  generate_league_table <- function(league) {
    # Filter top players by league
    league_top_players_df <-
      subset(top_players_df, LeagueNameLong == league)
    
    # Create table with league name as heading
    league_table <- tableOutput(paste0("league_", league))
    
    div(
      h4(league, style = "font-family: LEMON MILK; font-weight: bold; text-align: center; padding: 30px;"),
      league_table,
      renderTable(
        league_top_players_df %>%
          select(
            Player,
            Club,
            NationalTeam,
            Appearance,
            TotalGoals,
            TotalAssists,
            ShotsOnTarget
          ) %>%
          arrange(desc(TotalGoals)),
        outputId = paste0("top_players_", make.names(league))
      )
    )
  }
  
  output$player_tabs <- renderUI({
    tabs <- lapply(unique(top_players_df$LeagueNameLong), function(l) {
      tabPanel(l,
               generate_league_table(l))
    })
    do.call(tabsetPanel, tabs)
  })
  
  # Render the tables for each league
  lapply(unique(top_players_df$LeagueNameLong), function(l) {
    output[[paste0("league_", make.names(l))]] <- renderTable({
      top_players_df %>% filter(LeagueNameLong == l) %>%
        select(
          LeagueNameLong,
          Player,
          Club,
          NationalTeam,
          Appearance,
          TotalGoals,
          TotalAssists,
          ShotsOnTarget
        ) %>%
        arrange(desc(TotalGoals))
    })
  })
}


#############  SHINY APP
shinyApp(ui, server)
