!!!!!!!  READ IT MUST TO OPEN THE PROJECT


Step-1: Open the 'libraries.R' file in RStudio and instal necessary packeges and include it before
	starting the next steps.

Step-2: Open the '90MinsStat_Leagues.R' file and run the whole code.

Step-3: Open the '90MinsStat_Squads.R' file and run the whole code.

Step-4: Open the 'Features.R' file and run the whole code.

Step-5: Open the 'ui.R' file and run the whole code.