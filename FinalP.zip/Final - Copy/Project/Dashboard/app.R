library(shiny)
library(shinydashboard)
library(shinythemes)

ui <- dashboardPage(
  
  dashboardHeader(
    title = "90 MINS STAT",
    titleWidth = 450,
    titleFontFamily = "Roboto",
    titleColor = "lime",
    titleAlign = "center",
    tags$li(a(href = "https://github.com/your_username", icon("github")), class = "dropdown"),
    tags$li(a(href = "https://www.espnfc.com/", icon("futbol")), class = "dropdown"),
    tags$li(a(href = "https://www.foxsports.com/soccer", icon("tv")), class = "dropdown")
  ),
  dashboardSidebar(
    sidebarMenu(
      menuItem("About", icon = icon("info"), tabName = "about"),
      menuItem("Dataset", tabName = "dataset"),
      menuItem("Leagues", tabName = "leagues"),
      menuItem("Clubs", tabName = "clubs"),
      menuItem("Comparison", tabName = "comparison"),
      menuItem("Visuals", tabName = "visuals")
    )
  ),
  dashboardBody(
    # add your content here
  ),
  theme = shinytheme("slate")
)

server <- function(input, output, session) {
  # add server logic here
}

shinyApp(ui, server)
