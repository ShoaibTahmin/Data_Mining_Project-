#############################  TOTAL SHOTS #####################################

# load the data
allClubs_df <- read.csv("All Clubs Data.csv")
allSquads_df <- read.csv("All Squad Data.csv")

# Convert Shots column to numeric and replace NAs with 0 in allSquads_df
allSquads_df$Shots <- as.numeric(as.character(allSquads_df$Shots))
allSquads_df$Shots[is.na(allSquads_df$Shots)] <- 0

# Add a column 'League' to allSquads_df from allClubs_df based on the common column 'Club'
allSquads_df <- merge(allSquads_df, allClubs_df[, c("Club", "LeagueNameLong")], by = "Club", all.x = TRUE)
#View(allSquads_df)

# Aggregate shots by club in allSquads_df
clubShots_df <- aggregate(allSquads_df["Shots"], by=list(Club=allSquads_df$Club), FUN=sum)
names(clubShots_df)[2] <- "totalShots"

# Merge total shots with allClubs_df
allClubs_df <- merge(allClubs_df, clubShots_df, by="Club", all=TRUE)

# Replace any NAs with 0 in totalShots column
allClubs_df$totalShots[is.na(allClubs_df$totalShots)] <- 0

View(allClubs_df)
write.csv(allClubs_df, "Clubs.csv", row.names = FALSE)
write.csv(allSquads_df, "Players.csv", row.names = FALSE)


########################   TOP PLAYERS  #######################################

# Read Players.csv into a dataframe
players_df <- read.csv("Players.csv")

# Replace NA and "--" values with 0
players_df[is.na(players_df)] <- 0
players_df[players_df == "--"] <- 0

# Group by league and player name and calculate total goals, assists, and shots on target
top_players_leagues <- players_df %>%
  group_by(LeagueNameLong, Player) %>%
  mutate(Goals = as.numeric(Goals)) %>%
  mutate(Assist = as.numeric(Assist)) %>% # convert Assist column to numeric
  mutate(OnTarget = as.numeric(OnTarget)) %>% # convert OnTarget column to numeric
  summarise(
    Club = first(Club),
    NationalTeam = first(NT),
    Appearance = first(APP),
    TotalGoals = sum(Goals),
    TotalAssists = sum(Assist),
    ShotsOnTarget = sum(OnTarget)
  ) %>%
  ungroup() %>%
  
  # Select top 5 players by total goals in each league
  group_by(LeagueNameLong) %>%
  arrange(desc(TotalGoals)) %>%
  top_n(5, TotalGoals) %>%
  ungroup()

View(top_players_leagues)
# Write top players by league to a new csv file
write.csv(top_players_leagues, "Top Players.csv", row.names = FALSE)

################################################################################

