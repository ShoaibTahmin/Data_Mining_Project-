library(magrittr)
# load the data
clubs <- read.csv("Clubs.csv")
players <- read.csv("Players.csv")

# Club Comparison

# First, calculate the maximum points
clubs$max_points <- clubs$MatchPlayed * 3

# Then, filter the clubs with maximum points
clubs_max_points <- clubs[clubs$Points == max(clubs$max_points), "Club"]

# Calculate the point ratio for each team
clubs$point_ratio <- ((clubs$max_points - clubs$Points) / clubs$max_points) * 100

# Calculate the points-per-match for each team
clubs$points_per_match <- clubs$Points / clubs$MatchPlayed

# Categorize the points-per-match into low, medium, and high categories
clubs$points_per_match_category <- cut(clubs$points_per_match, breaks = c(0, 1.5, 2.5, 3), labels = c("Low", "Medium", "High"))

# Show the resulting data frame
View(clubs)


# Write points ratio by clubs to a new csv file
write.csv(clubs, "Clubs.csv", row.names = FALSE)




# Players Comparison

# Shot Accuracy 

# checking if there are any non-numeric values in the 'Shots' and 'OnTarget' columns using the is.numeric function
sum(!is.numeric(players$Shots))
sum(!is.numeric(players$OnTarget))

# using the as.numeric function to convert these columns to numeric
players$Shots <- as.numeric(players$Shots)
players$OnTarget <- as.numeric(players$OnTarget)

# calculating the shot accuracy 
players$Shot_Acc <- round(players$OnTarget/players$Shots, 2)

# converting them to numeric using the as.numeric() function
players$Saves <- as.numeric(players$Saves)
players$Conceded <- as.numeric(players$Conceded)

# shows the total saves for each player
players <- players %>% mutate(Total_Saves = Saves + Conceded)

# convert data type to numeric
players$Goals <- as.numeric(players$Goals)
players$OnTarget <- as.numeric(players$OnTarget)

# calculate the expected goals
players$Expected_Goals <- round(players$Goals/players$OnTarget, 2)


View(players)

write.csv(players, "Players.csv", row.names = FALSE)

